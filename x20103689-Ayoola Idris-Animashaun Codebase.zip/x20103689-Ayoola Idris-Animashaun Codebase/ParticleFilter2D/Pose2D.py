import numpy as np
import math

np.random.seed(17)

class Pose2D:
    """Helper class containing a number static methods for creating and manipulating 2D poses"""

    @staticmethod
    def randomPoses(num_poses, worldsize):
        """Generates a numpy array of random poses

        Args:
            num_poses (int): number of poses to generate
            worldsize  (float): specifies dimensions of the world (i.e. the 
                maximum values for the pose x and y values).
        
        Returns:
            np.array: Nx3 numpy array of generated poses where each pose contains the pose's
                [x, y, theta] values where theta is stored in radians.
        """
        return np.array((np.random.uniform(0.0, worldsize, num_poses),
                np.random.uniform(0.0, worldsize, num_poses),
                np.random.uniform(-np.pi, np.pi, num_poses))).T

    @staticmethod
    def originPoses(num_poses, worldsize):
        """Generates a numpy array of zero poses (i.e. all having the values [0, 0, 0])

        Args:
            num_poses (int): number of poses to generate
            worldsize  (float): specifies dimensions of the world (i.e. the 
                maximum values for the pose x and y values).
        
        Returns:
            np.array: Nx3 numpy array of generated poses where each pose contains the pose's
                [x, y, theta] values where theta is stored in radians.
        """
        return np.tile(
            np.array([worldsize/2.0, worldsize/2.0, np.pi/2]),
            (num_poses,1))

    @staticmethod
    def addOdometry(poses, odometry):
        """Applies odometry to input poses

        Applies the (non-probabilistic / deterministic) kinematic motion model from the
        CS427 particle filter notes by propagating the set of input poses according to 
        the input odometry. 

        Args:
            poses (np.array): Nx3 numpy array of poses where each pose contains the pose's
                [x, y, theta] values where theta is stored in radians.
            odometry (np.array): 1x3 or Nx3 numpy array of odometry parameters [dx, dy, dtheta].
                If the the structure is 1x3 it applies the same odometry to all
                poses. If the structure is Nx3 the i'th vector in odometry is applied
                to the i'th vector in poses.

        Returns:
            np.array: Nx3 numpy array of updated poses where each pose contains the pose's
                [x, y, theta] values where theta is stored in radians. 
        """        

        ## STEP 1: Implement the transformation to apply the odometry to the
        ##          inputted poses. WARNING: Note that when you compute the 
        ##          final orientation you should normalise its value. This 
        ##          can be done by using the Pose2D.normaliseAngle function below.
        if(odometry.ndim > 1): #a different rotation for each pose
            world_odom =  np.array([Pose2D.getWorldOdometry(i,j) for i,j in zip(odometry, poses)])
            poses = poses + world_odom
        else: #a single rotation for all the poses
            world_odom = np.array([Pose2D.getWorldOdometry(odometry,j) for j in poses])
            poses = poses + world_odom
        
        
        poses[:,2] = np.array([Pose2D.normaliseAngle(i) for i in poses[:,2]])
        return poses 

    @staticmethod
    def getWorldOdometry(local_odometry, pose): #this method seems is a bit slow, could probably do a single matrix vector multiplication
        """ Rotates each odometry instruction in pose coordinate frame   """
        c = np.cos(pose[2])
        s = np.sin(pose[2])
        R = np.array([[c, -s, 0],[s, c, 0], [0,0,1]])
        world_odom = np.dot(R,  local_odometry)
        return world_odom
        
    @staticmethod
    def normaliseAngle(angle):
        """Normalises the input angle to the range ]-pi/2, pi/2]"""        
        if ((angle < np.pi) and (angle >= -np.pi)):
            return angle
        pi2 = np.pi*2
        nangle = angle - (int(angle/(pi2))*(pi2))
        if (nangle >= np.pi):
            return nangle - pi2
        elif (nangle < -np.pi):
            return nangle + pi2
        return nangle 