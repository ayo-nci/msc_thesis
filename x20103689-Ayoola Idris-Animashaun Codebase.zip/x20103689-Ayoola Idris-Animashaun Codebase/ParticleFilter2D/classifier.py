import numpy as np
import pandas as pd
import pickle
import sklearn
from scipy import stats

class robotclassifier:
    def __init__(self):
        mode_of_result = 0

    def load_and_apply_model(four_robot_poses, steps):
    
        loaded_model_1 = pickle.load(open(str(steps) + '_steps_RF_robot_model_weights.sav', 'rb'))
        #loaded_model_2 = pickle.load(open(str(steps) + '_steps_DT_robot_model_weights.sav', 'rb'))
        #print("4 robot poses: ", four_robot_poses)
        #result = [None,None]
        result = loaded_model_1.predict(four_robot_poses[-1].reshape(1,-1))
        #result[1] = loaded_model_2.predict(four_robot_poses[-1].reshape(1,-1))
        print("RF Prediction is: ", result)#, "and DT prediction is: ", result[1][0])
        #pick the most occuring class
        #mode_of_result = np.bincount(result).argmax()
        
        #result=[result[0][0],result[1][0]]
        #print("res is :", result)
        #applied_result = np.random.choice(result, p = [0.5,0.5])
        applied_result = result
        print("And applied result is : ", applied_result)
        
        if applied_result == 'fw':
            model = 'fw'
        elif applied_result == 'tf':
            model = 'fw'
        else:
            model = 'ow'

        return model