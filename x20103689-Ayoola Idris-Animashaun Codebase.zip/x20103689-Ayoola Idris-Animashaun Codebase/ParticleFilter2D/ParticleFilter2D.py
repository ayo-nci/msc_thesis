import numpy as np
import random 

from ParticleFilter2D.Pose2D import Pose2D
from ParticleFilter2D.MotionModel import MotionModel
from ParticleFilter2D.SensorModel import SensorModel

np.random.seed(16)

class ParticleFilter2D:
    """2D (i.e. 3-DoF) Particle Filter.

    Implements the 2D particle filtering algorithm covered during CS427
    and in Thrun et al. Ch4 and Ch8.

    Attributes:
        worldsize (float): size of x and y world dimensions
        poses (array): Nx3 numpy array of particle poses where each pose contains
            the pose's [x, y, theta] values, where theta is stored in radians.
        weights (array): numpy array of N importance particle weights
        motionModel (MotionModel): see MotionModel
        sensorModel (SensorModel): see SensorModel
    """

    def __init__(self, num_particles=50, worldsize = 750):
        """Instantiates a new ParticleFilter2D with num_particles and a worldsize.

        Create a new ParticleFilter2D object containing num_particles particles
        and operating of the size worldsize.

        Args:
            num_particles (int): Number of particles to use in the filter 
                (default: 50).
            worldsize (float): Size of the world in x and y dimensions
                (default: 750).
        """
        self.worldsize = worldsize
        self.poses = Pose2D.randomPoses(num_particles, worldsize)
        self.weights = np.ones((num_particles), dtype=float)/num_particles
        
        ####
        #Introduce parameters for wheel constraints
        ####
        
        

        self.motionModel = MotionModel()
        self.sensorModel = SensorModel()
        
    

    def processFrame(self, odometry, measurements, landmarks, model):
        """Perform a single predict, update, resample iteration.

        Args:
            odometry (array): 1x3 numpy array of odometry parameters 
                [dx, dy, dtheta] 
            measurements (list): list of SensorMeasurements.
            landmarks (array): Nx2 array of landmark [x, y] location vectors.            
        """
        self.processMotion(odometry, model)
        self.processSensor(measurements,landmarks)

        self.resample()

    def processSensor(self, measurements, landmarks):
        """Process sensor measurements and update weights.

        Performs updated step of the particle filtering algorithm.
        
        Args:
            measurements (list): list of SensorMeasurements.
            landmarks (array): Nx2 array of landmark [x, y] location vectors.
        """        

        ## STEP 5: Add code here that computes the importance weights
        ##          for each pose by calling the relevant method from
        ##          SensorModel 
        
       
        
        self.weights = np.array([self.sensorModel.likelihood(pose, measurements, landmarks) for pose in self.poses])
            
        
         
        
        

    def processMotion(self, odometry, model):
        """Process odometry by propagating particles using given odometry.

        Performs prediction step of the particle filtering algorithm.
        
        Args:
            odometry (array): 1x3 numpy array of odometry parameters 
                [dx, dy, dtheta] 
        """                
        #print("The pfs odometry is ", odometry)
        self.poses = self.motionModel.propagatePoses(self.poses, odometry, model)

    def resample(self):
        """Perform resampling step.

        Resample particles by drawing M particles with replacement where each 
        particle has a probability of being selected based on its current
        weight.
        """    
        ## STEP 6: Provide an implementation of the stochastic universal sampling
        ##          algorithm
        
        
        new_pose = np.zeros(3) #something to vstack onto
        M  = len(self.weights) #number of weights
        delta = 1.0 / M #avg increment to maintain M particles
        r = delta * np.random.rand() #value between 0 and delta for randomness
        
        weight_sum = np.sum(self.weights)
        if(weight_sum>0): #prevent a division by zero
            eta = 1 / weight_sum
            norm_weights = self.weights * eta #scale the weights between 0-1
        else:
            norm_weights = np.ones(M) * delta #all equally likely
        c = norm_weights[0] #first particle weight
        i = 0 #first index
        for m in range(0,M):
            U = r+((m) * delta) #nominated weight to consider
            while(U > c): 
                i += 1
                c += norm_weights[i]
            new_pose = np.vstack((new_pose, self.poses[i]))

        
        self.poses = new_pose[1:] #removes the zeroes at the top
        
    


   
        


    def __str__(self):
        rstr = '\n'.join(["x: {}, y: {}, angle: {}, weight: {}".format(p[0], p[1], p[2], w)
            for p,w in zip(self.poses.T, self.weights)])
        return rstr 
        
        
        
        
       
        
        