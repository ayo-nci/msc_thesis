"""ParticleFilter2D driver script

This script provides driver code for setting up a simulated environment (i.e. WorldModel)
and ParticleFilter2D (and associated classes). It then display the environment and allows
the user to interact with it via the keys:
Movement:
'w': forward
's': backward
'a': rotate-left
'd': rotate-right
Other:
'q': quit
"""
from ParticleFilter2D import WorldModel, SensorModel, WorldDrawer, ParticleFilter2D, classifier

import numpy as np
import cv2
import csv

def keyboardHandler(key):
    """Returns np.array for odometry parameters based on the input key.
    
    Args:
        key (int): input character from {'w','a','s','d'} corresponding to forward, rotate-left, etc.

    Returns:
        np.array: [x, y, theta] corresponding to odometry given the input key (or [0, 0, 0] otherwise).
    """
    
    
    keycode = chr(key & 255)
    if (keycode == 'w'):
        return np.array([10, 0, 0], dtype='float64')
    elif (keycode == 's'):
        return -np.array([10, 0, 0], dtype='float64')
    elif (keycode == 'd'):
        return np.array([0, 0, np.pi*0.05], dtype='float64')
    elif (keycode == 'a'):
        return -np.array([0, 0, np.pi*0.05], dtype='float64')
    #elif (keycode == 'z'):
        return -np.array([0, 10, np.pi*0.05], dtype='float64')
    #elif (keycode == 'x'):
        return -np.array([0, -10, np.pi*0.05], dtype='float64')
    return np.array([0, 0, 0], dtype='float64')

def main():
    ## Simulation parameters
    
    kinematics_model = ['fw','om']
    
    
    NUM_LANDMARKS = 30
    NUM_PARTICLES = 150
    WORLDSIZE = 750

    ## Create simulated environment
    wm = WorldModel(WORLDSIZE)

    ## Add landmarks / map 
    np.random.seed(16)
    landmarks = np.random.uniform(0,WORLDSIZE,(NUM_LANDMARKS,2))
    wm.addLandmarks(landmarks)
    
    #robot_poses = []
    #robot_poses.append(wm.currentPose)

    ## Sensor model for generating measurements
    sm = SensorModel()

    ## Instantiate a particle filter
    pf = ParticleFilter2D(NUM_PARTICLES)
    
    #print("wm current pose is ", wm.currentPose)
    #print("pf current pose is ", pf.poses)
    
    ## Create visualisation
    key = 0
    wd = WorldDrawer(WORLDSIZE)
    
    
    
    steps = 1000
    
    
    model = np.random.choice(['fw','ow'], p = [1,0])
    print("chosen model is :", model)
    count = 0
    pf_trackers = [None, None,None, None]
    pf_tracker = []
    pf_dic = {}
    

    
    while ('q' != chr(key & 255)):
        pred_model = 'fw'
        
        odometry = keyboardHandler(key)
        wm.addOdometry(odometry)
        
        ## Generate measurements
        measurements = wm.sampleMeasurements(sm)

        ## Execute filter 
        pf.processFrame(odometry, measurements, wm.landmarks, pred_model)

        ## Render world
        wd.drawWorld(wm)
        wd.drawParticles(pf)
        wd.showImage()



        #key = cv2.waitKey(0)


        step = 5
        if len(wm.robotArray) % step == 0:
            robotPoses = [list(arr.flatten()) for arr in wm.robotArray]
            robotPoses = np.reshape(robotPoses,(int(len(wm.robotArray)/step),step * 3))
            
            pred_model = classifier.robotclassifier.load_and_apply_model(robotPoses, step)
            print("Applied updated kinematic model: ", pred_model)
            pf.processFrame(odometry, measurements, wm.landmarks, pred_model)
            
            
        #show graph showing sum  of difference btw pf and robot poses for each step 
        #along with if landmark is seen at the step
        
        print("wm current pose is ", wm.currentPose)
        #print("pf current pose is ", pf.poses)
        print("Visible measurements is/are: ", measurements)
        print("Len Visible measurements is/are: ", len(measurements))
        
        
        #if odometry.any():
            #Calc the eqn distance from robot to particle
            #eqn_distance = wm.currentPose - pf.poses
        new_pf_poses = pf.poses[:,:-1]
        
        eqn_distance, eqn_bearing = sm._SensorModel__senseAllLandmarks(wm.currentPose,new_pf_poses)
        count = count + 1
        isVisibleLandmark = len(measurements)
         
        print("step is: ", count, "dist is: ", np.mean(eqn_distance), "angle is: ", np.mean(eqn_bearing), "and how many Visible Landmark : ",isVisibleLandmark)
        
        pf_dic[count] = [count, np.mean(eqn_distance), np.mean(eqn_bearing), isVisibleLandmark]
        #key = 113
        key = cv2.waitKey(0)
        
    pf_dic = [item for item in pf_dic.values()]
    print(pf_dic)
    fields = ['step', 'avg distance: robot to particle', 'avg bearing: robot to particle', 'No of visible landmarks']
    with open("manual particle tracking.csv", 'w') as g:
        csvwriter = csv.writer(g)
        csvwriter.writerow(fields)
        csvwriter.writerows(pf_dic)


cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
