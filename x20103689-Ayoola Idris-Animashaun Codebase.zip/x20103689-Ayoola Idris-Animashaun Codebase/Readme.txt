Installation

This codebase requires the following libraries installed. 
1. Jupyter Notebook
2. Numpy
3. Scipy
4. OpenCV
5. Random

Phase 1 - Initializing the robot

Step 1: Run 'robot driver auto before motion model'.py from the command line by typing "python3 'robot driver auto before motion model'.py -steps 100" into the command line. You can enter 5, 10, 20, 50 or 100 only steps only. Please enter 100 to replicate this project. 

Step 2: A file titled, "Before motion model (Number of steps you selected from Step 1) steps particle tracking auto.csv" will be available after Step 1 is done running. 

Step 3: Run the "particle tracker before motion model".ipynb file in a Jupyter Environment

Step 4: A plot of the average distance between the robot and each particles will be plotted. The aim of this research is to get an average number that is lesser than this average. 

Phase 2 - Generating the robot poses
Step 1: From the Jupyter home of this directory. Run the 'robot wheel generator".ipynb file in Jupyter to synthesize robot poses. This file will generate robot poses for 5, 10, 20, 50 and 100 steps each for a single fixed wheel, an omni wheel and a two fixed wheels. This will be used later by the classifiers we will build. The last cell in this notebook will generate test data that none of the classifiers will have seen. This will be used to ensure there is no over-fitting during hyper-parameter tuning

Step 2: Still in the jupyter home, run the 'Classifier Analysis'.ipynb file to see how the selected classifiers perform on the data generated in step 1 of Phase 2. The initial execution will run for 100 robot steps. A table of comparison among the classifiers will be presented along with the confusion matrix for each classifier. The following execution will then run for 5, 10, 20, 50, 100 to improve the performance of each classifier based on more input to the classifier. We see that the performance of the classifiers will improve with more steps. We see that KNN has a high log loss and so we will exclude it from the next stage where we tune the hyper-parameters on the models.

Step 3-5 is the same but for different classifiers

Step 3a: Run the 'Hyperparameter Tuning Decision Tree'.ipynb file. It will tune hyper-parameters for 100 robot steps initially. The output will contain the best parameters and plot of the test vs train error for accuracy and log loss. The second run will use the tuned hyper-parameters values to see how the model performance improves with more robot steps. A plot of accuracy and log loss will be displayed at the end of the run.

Step 3b. Run the 'Test Overfitting Decision Tree'.ipynb file to be sure the model in 3a has not been overfitted and can be generalised. PLEASE NOTE THAT STEP 3A MUST BE CARRIED OUT BEFORE THIS STEP CAN BE CARRIED OUT DUE TO THIS STEP USING THE WEIGHTS FROM STEP 3A FOR PREDICTION


Step 4a: Run the 'Hyperparameter Tuning Random Forest'.ipynb file. It will tune hyper-parameters for 100 robot steps initially. The output will contain the best parameters and plot of the test vs train error for accuracy and log loss. The second run will use the tuned hyper-parameters values to see how the model performance improves with more robot steps. A plot of accuracy and log loss will be displayed at the end of the run.

Step 4b. Run the 'Test Overfitting Random Forest'.ipynb file to be sure the model in 4a has not been overfitted and can be generalised. PLEASE NOTE THAT STEP 4A MUST BE CARRIED OUT BEFORE THIS STEP CAN BE CARRIED OUT DUE TO THIS STEP USING THE WEIG=HTS FROM STEP 4A FOR PREDICTION


Step 3a: Run the 'Hyperparameter Tuning Logistic Regression'.ipynb file. It will tune hyper-parameters for 100 robot steps initially. The output will contain the best parameters and plot of the test vs train error for accuracy and log loss. The second run will use the tuned hyper-parameters values to see how the model performance improves with more robot steps. A plot of accuracy and log loss will be displayed at the end of the run.

Step 3b. Run the 'Test Overfitting Logistic Regression'.ipynb file to be sure the model in 3a has not been overfitted and can be generalised. PLEASE NOTE THAT STEP 3A MUST BE CARRIED OUT BEFORE THIS STEP CAN BE CARRIED OUT DUE TO THIS STEP USING THE WEIGHTS FROM STEP 3A FOR PREDICTION



Phase 3
Step 1: Run the 'Tuned Random Forest'.ipynb file to generate model weights for 5, 10, 20, 50, 100 robot steps.

Step 2: Run 'robot_driver_auto'.py from the command line by typing "python3 'robot_driver_auto'.py -steps 100" into the command line. You can enter 5, 10, 20, 50 or 100 only for steps. This will determine the number of steps before a robot processes a prediction of the wheel type it has and apply the necessary motion constraint to its particles. Please enter 100 to replicate this project. 

Step 3: A file titled, "After motion model (Number of steps you selected from Step 1) steps particle tracking auto.csv" will be available after Step 2 is done running. 

Step 4: Run the "particle tracker after motion model".ipynb file in a Jupyter Environment

Step 5: Two plots of the average distance between the robot and each particle for before the motion model was added and for after the motion model was added will be plotted. The average distance will be shown after each plot. We will see that the distance for the after the motion model was added is lesser than the distance before the motion model was added. This shows that the particles were constrained and moved in close proximity with the robot within the space, especially for moments when a landmark was not visible.

Step 6: Run the "robot_driver'.py file from the command line to interact with the live robot environment and see the particles converge around the robot as you navigate it through the environment. Use keys 'a', 'd' to rotate the robot clockwise and anti-clockwise, and the keys 'w','s' to move the robot forward and backwards. It does not require a number of steps to run. You can remove the set seed on line 60 to generate a new environment on every run. 


Many thanks to William Clifford for the supervision on this project.

The end