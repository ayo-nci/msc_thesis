"""ParticleFilter2D driver script

This script provides driver code for setting up a simulated environment (i.e. WorldModel)
and ParticleFilter2D (and associated classes). It then display the environment and allows
the user to interact with it via the keys:
Movement:
'w': forward
's': backward
'a': rotate-left
'd': rotate-right
Other:
'q': quit
"""
from ParticleFilter2D import WorldModel, SensorModel, WorldDrawer, ParticleFilter2D, classifier

import numpy as np
import cv2
import csv
import argparse



def keyboardHandler(key):
    """Returns np.array for odometry parameters based on the input key.
    
    Args:
        key (int): input character from {'w','a','s','d'} corresponding to forward, rotate-left, etc.

    Returns:
        np.array: [x, y, theta] corresponding to odometry given the input key (or [0, 0, 0] otherwise).
    """
    
    
    keycode = chr(key & 255)
    if (keycode == 'w'):
        return np.array([10, 0, 0], dtype='float64')
    elif (keycode == 's'):
        return -np.array([10, 0, 0], dtype='float64')
    elif (keycode == 'd'):
        return np.array([0, 0, np.pi*0.05], dtype='float64')
    elif (keycode == 'a'):
        return -np.array([0, 0, np.pi*0.05], dtype='float64')
    #elif (keycode == 'z'):
      #  return -np.array([0, 10, np.pi*0.05], dtype='float64')
    #elif (keycode == 'x'):
     #   return -np.array([0, -10, np.pi*0.05], dtype='float64')
    return np.array([0, 0, 0], dtype='float64')

def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("-steps", "--Steps", help = "Enter number of steps from range 5, 10, 20, 50, 100")

    args = parser.parse_args()
    ## Simulation parameters
    
    kinematics_model = ['fw','om']
    
    
    NUM_LANDMARKS = 30
    NUM_PARTICLES = 150
    WORLDSIZE = 750

    ## Create simulated environment
    wm = WorldModel(WORLDSIZE)

    ## Add landmarks / map 
    np.random.seed(17)
    landmarks = np.random.uniform(0,WORLDSIZE,(NUM_LANDMARKS,2))
    wm.addLandmarks(landmarks)
    
    #robot_poses = []
    #robot_poses.append(wm.currentPose)

    ## Sensor model for generating measurements
    sm = SensorModel()

    ## Instantiate a particle filter
    pf = ParticleFilter2D(NUM_PARTICLES)
    
    #print("wm current pose is ", wm.currentPose)
    #print("pf current pose is ", pf.poses)
    
    ## Create visualisation
    key = 0
    wd = WorldDrawer(WORLDSIZE)
     
    loop = 100
    steps = int(args.Steps)

    
    #print("steps is: ", steps)
    #print("steps is: ", dir(args))
    
    
    #model = np.random.choice(['fw','ow'], p = [0.5,0.5])
    #print("chosen model is :", model)
    count = 0
    pf_trackers = [None, None,None, None]
    pf_tracker = []
    pf_dic = {}
    model_dic = {}

    
    while ('q' != chr(key & 255)):
        np.random.seed(17)
        #uncomment the next line to get readings for a omni-wheel robot only
        #model = np.random.choice(['fw','ow'], p = [0,1])
        #uncomment the next line to get readings for the particles to move with a omni-wheel motion only
        pred_model = np.random.choice(['fw','ow'], p = [0,1])
        #uncomment the next line to get readings for a fixed-wheel robot only
        model = np.random.choice(['fw','ow'], p = [1,0])
        #uncomment the next line to get readings for the particles to move with a fixed-wheel motion only
        #pred_model = np.random.choice(['fw','ow'], p = [1,0])
        #uncomment the next line to get readings for both fixed and omni-wheel types for the robot
        #model = np.random.choice(['fw','ow'], p = [0.5,0.5])
        print("rb chosen model initially is :", model)
        
        for i in range(steps * 10):
            #start pf with ow
            print("chosen rb model b4 prediction:", model)
            print("chosen pf model bb4 prediction:", pred_model)
            
            
            if model == 'fw':
                key_fw = np.random.choice([115,119])
                odometry = keyboardHandler(key_fw)
                print("key fw is ",key_fw)

                #Get robot poses that agrees with omni wheel constraints
            else:
                key_om = np.random.choice([97,100,115,119,120,122])
                odometry = keyboardHandler(key_om)
                print("key om is ",key_om)

            #odometry = keyboardHandler(key)
            wm.addOdometry(odometry)
            
            ## Generate measurements
            measurements = wm.sampleMeasurements(sm)
            
            ## Execute filter 
            pf.processFrame(odometry, measurements, wm.landmarks, pred_model)

            ## Render world
            wd.drawWorld(wm)
            wd.drawParticles(pf)
            wd.showImage()
            #key = cv2.waitKey(0)

            step = steps
            
            if len(wm.robotArray) % step == 0:
                robotPoses = [list(arr.flatten()) for arr in wm.robotArray]
                robotPoses = np.reshape(robotPoses,(int(len(wm.robotArray)/step),step * 3))
                
                pred_model = classifier.robotclassifier.load_and_apply_model(robotPoses, step)
                print("Applied updated kinematic model: ", pred_model)
                #pf.processFrame(odometry, measurements, wm.landmarks, pred_model)
                
                model_dic[len(wm.robotArray)] = [model, pred_model]
                #model = pred_model
                #Because we are simulating the robots motion, we randomly choose a new model after we ask for a prediction from the classifier
                #model = np.random.choice(['fw','ow'], p = [0.5,0.5])
                #print("chosen rb model after prediction:", model)
                #print("chosen pf model after prediction:", pred_model)
                
            new_pf_poses = pf.poses[:,:-1]
            
            eqn_distance, eqn_bearing = sm._SensorModel__senseAllLandmarks(wm.currentPose,new_pf_poses)
            count = count + 1
            isVisibleLandmark = len(measurements)
             
            #print("step is: ", count, "dist is: ", np.mean(eqn_distance), "angle is: ", np.mean(eqn_bearing), "and how many Visible Landmark : ",isVisibleLandmark)
            
            pf_dic[count] = [count, np.mean(eqn_distance), np.mean(eqn_bearing), isVisibleLandmark]
        key = 113
            
    pf_dic = [item for item in pf_dic.values()]
    #print(pf_dic)
    print(model_dic)
    fields = ['step', 'avg distance: robot to particle', 'avg bearing: robot to particle', 'No of visible landmarks']
    with open("After motion model" + str(steps) + " steps particle tracking auto.csv", 'w') as g:
        csvwriter = csv.writer(g)
        csvwriter.writerow(fields)
        csvwriter.writerows(pf_dic)


cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
